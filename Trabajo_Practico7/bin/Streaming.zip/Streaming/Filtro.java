package Streaming;

public abstract class Filtro {

	public abstract boolean cumple(Pelicula peli); 
}
